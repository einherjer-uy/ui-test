# Backbone Upload Manager

A simple upload manager written with Backbone.js.

* [Demonstration and usage](http://sroze.github.io/backbone-upload-manager)

